# Real-Estate-ML
Real Estate property sale price prediction using a 2001-2022 dataset.
